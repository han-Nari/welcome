let pass = document.querySelector('#password')
	let cpass = document.querySelector('#cpassword');
	let message = document.querySelector('.message');
	let cmessage = document.querySelector('.cmessage');
	let str = document.querySelector('#strength');
	let cstr = document.querySelector('#cstrength');

	pass.addEventListener('input', ()=> {
		if(pass.value.length > 0) {
			message.style.display = 'block';
		} else {
			message.style.display = 'none';
		}

		if(pass.value.length < 6) {
			str.innerHTML = 'weak';
			message.style.color = '#f00000';
		} else if(pass.value.length >= 6) {
			str.innerHTML = 'strong';
			message.style.color = '#00ff00';
		}
	});

	cpass.addEventListener('input', ()=> {
		if(cpass.value.length > 0) {
			cmessage.style.display = 'block';
		} else {
			cmessage.style.display = 'none';
		}

		if(cpass.value.length < 6) {
			cstr.innerHTML = 'weak';
			cmessage.style.color = '#f00000';
		} else if(cpass.value.length >= 6) {
			cstr.innerHTML = 'strong';
			cmessage.style.color = '#00ff00';
		}
	});